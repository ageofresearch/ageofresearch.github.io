# Foso de filtros · R01

Escena Blender editable del hueco central bajo las tapas del piso, reconstruida desde la fotografía de mantenimiento IMG-20261016-WA0004.jpg (1200 × 1600). La fotografía permanece privada y no se incluye en este archivo ni en texturas publicadas.

## Alcance

235 componentes editables: marco galvanizado, dos cuerpos huecos y tapas, racores, cuatro mandos negros, puente con válvula azul descentrada, colector delantero, dos volantes centrales y uno lateral, manguera enrollada, tuberías finas, conexiones y apoyos visibles dentro del foso. Los motores, paredes y equipos externos son contexto existente y no forman parte de esta escena.

Unidades en metros. Ejes fuente: X hacia proa, Y hacia babor, Z arriba. El archivo Blender conserva la transformación existente al visor. La cámara estimada se congela en photo-camera.json; se ajustó usando los aros nominales, no mediciones independientes del barco.

## Autoría y ejecución

Abrir filter-well-master.blend en Blender 4.3.2. La colección EDITABLE contiene las piezas separadas. Las tres mallas FW installed son derivadas para el navegador; sus roles fijo/tapa y el lado están en propiedades personalizadas. El HDR EXR y los mapas procedurales están empaquetados en el Blender. UV0 tiene escala física de 12 cm y UV1 pertenece a la iluminación.

Cycles: 64 muestras, difuso directo e indirecto sin albedo, EXR lineal de 2048². La distribución de luces es un contexto estimado: incluye sustitutos de rebote de las superficies blancas circundantes, que no representan luminarias observadas. En navegador se usa un derivado lineal de 1024² RGBM128/KTX2 y transportes por esquina para detalles pequeños. Los reflejos locales existentes del cuarto se comparten. No se modificaron los motores ni sus acabados.

prepare-filter-well.mjs retira 44 triángulos de dos tapas internas coincidentes del empalme delantero. Conserva la pared exterior del conducto. Las piezas de autoría permanecen independientes y editables. El travesaño central tiene una posición estimada que permite mantener una holgura de 10 mm durante el movimiento nominal de las tapas.

## Comparación y límites

Se preparó comparación privada foto / software anterior / candidato, con cuadrícula nativa de 8 × 8 px y 4 × 4 px en detalles. Crear o medir una celda no equivale a aceptarla. No se afirma coincidencia de todos los bordes a cuatro píxeles ni equivalencia fotogramétrica. Profundidad, asientos y tramos ocultos siguen siendo inferidos. El desgaste fino, algunos racores y las sombras conservan diferencias frente a la fotografía.

Las pruebas usan Chromium/SwiftShader para corrección; no acreditan FPS en GPU real. Consultar validation.json y geometry-proof.json. Los 629 archivos del yate original, los 73 activos protegidos de motores e inspección y la estrategia LDM-VR-EST-001 v1.0 se mantienen sin cambios.

## Procedencia

Geometría y mapas nuevos creados para este proyecto. Referencia de mantenimiento suministrada por el usuario; no se publican sus píxeles. Dependencias: Three.js 0.180.0 (MIT), meshoptimizer 1.3.0 (MIT), xatlas 0.0.11 (MIT); herramientas de autoría Blender/Cycles 4.3.2. Las licencias existentes de las piezas nominales se conservan en el proyecto original.
