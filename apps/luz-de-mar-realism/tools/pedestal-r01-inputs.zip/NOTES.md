# Pedestal eléctrico · corrección del parpadeo R01

Reparación de las superficies coincidentes en los extremos del pedestal. La unión completa sustituye 176 triángulos por una frontera cerrada de 404 triángulos, incluidos los biseles y encuentros del frente.

Verificado: cero solapamientos en 1.496 pares coplanares, 80 rayos visibles con una única superficie, movimiento/reposo con buffer constante e imágenes idénticas desde la misma cámara, 17 archivos de pruebas, carga fallida/hash/reintento, ambos cortes y reproducción, filtros, registro, puerta y regreso al cuarto.

El ZIP contiene el Blender editable, geometría de entrada y salida, scripts de reconstrucción, capturas y resultados. Los siete HDR conservan sus bytes: se identifican por hash y permanecen en la entrega anterior y en los activos publicados. El master anterior permanece en la Release luz-generator-vr-r01.

La comprobación gráfica usa Chromium/SwiftShader y no constituye una medición de FPS en GPU real. No se incluyen fotografías VR. Los 629 archivos originales y 73 activos de motores e inspección se conservan.
