"""Author Luz de Mar's photo-fitted sea strainers and export evaluated web LODs.

blender -b -Y --python build-seawater-strainers.py -- --out DIR --blend FILE
All dimensions are visual estimates, not OEM or surveyed installation dimensions.
"""
import argparse
import array
import gzip
import hashlib
import json
import math
from pathlib import Path
import sys

import bpy
import bmesh
from mathutils import Vector

VERSION = 'luz-seawater-strainers-1'
PI = math.pi
args = argparse.ArgumentParser()
args.add_argument('--out', required=True)
args.add_argument('--blend', required=True)
args.add_argument('--render-dir')
opt = args.parse_args(sys.argv[sys.argv.index('--') + 1:])
out = Path(opt.out); out.mkdir(parents=True, exist_ok=True)
blend = Path(opt.blend); blend.parent.mkdir(parents=True, exist_ok=True)
bpy.ops.wm.read_factory_settings(use_empty=True)
scene = bpy.context.scene
scene.name = '01 CONJUNTO | escala estimada'
scene.unit_settings.system = 'METRIC'
scene.unit_settings.scale_length = 1
scene.render.fps = 30; scene.frame_start = 1; scene.frame_end = 121
scene['basis'] = 'Owner VID-20261019-WA0000 and five maintenance photographs. Brand, alloy, DN and dimensions unverified.'
scene['source_axes'] = 'X forward, Y port, Z up. Template origin is base of housing.'
scene['installation_source_metres'] = json.dumps({'x':12.14,'y':[-.27,.27],'z':.77})
template = bpy.data.collections.new('TEMPLATE | piezas exportadas'); scene.collection.children.link(template)
materials = {}

def mat(name, color, rough=.35, metal=0):
    m = bpy.data.materials.new(name); m.diffuse_color = (*color, 1); m.use_nodes = True
    s = m.node_tree.nodes.get('Principled BSDF'); s.inputs['Base Color'].default_value = (*color, 1)
    s.inputs['Roughness'].default_value = rough; s.inputs['Metallic'].default_value = metal
    m['roughness'] = rough; m['metalness'] = metal; materials[name] = m
    return m

white = mat('Pintura blanca', (.76,.79,.76), .29, .08)
bronze = mat('Metal cobrizo | aleación sin identificar', (.38,.245,.12), .42, .72)
steel = mat('Aspecto inoxidable | grado sin identificar', (.52,.58,.59), .29, .87)
black = mat('Junta negra', (.016,.021,.019), .72)
valve = mat('Palanca negra', (.024,.032,.035), .27, .18)
blue = mat('Cuerpo de válvula azul verdoso', (.025,.24,.32), .32, .2)
red = mat('Palanca de purga roja', (.55,.026,.02), .32, .12)
dirt = mat('Incrustación ilustrativa de la fotografía', (.080,.061,.029), .94)
nodes=dirt.node_tree.nodes;links=dirt.node_tree.links;noise=nodes.new('ShaderNodeTexNoise');noise.inputs['Scale'].default_value=420;noise.inputs['Detail'].default_value=3
bump=nodes.new('ShaderNodeBump');bump.inputs['Strength'].default_value=.55;bump.inputs['Distance'].default_value=.002
links.new(noise.outputs['Fac'],bump.inputs['Height']);links.new(bump.outputs['Normal'],nodes.get('Principled BSDF').inputs['Normal'])
green = mat('Unión equipotencial verde', (.05,.29,.09), .62)
yellow = mat('Unión equipotencial amarilla', (.65,.49,.018), .62)

def register(ob, material, role='fixed', kind='exterior'):
    for col in list(ob.users_collection): col.objects.unlink(ob)
    template.objects.link(ob)
    ob.data.materials.append(material); ob['role'] = role; ob['kind'] = kind; ob['evidence'] = 'photo-fitted; dimensions estimated'
    return ob

def mesh(name, vertices, faces, material, role='fixed', kind='exterior', smooth=True):
    data = bpy.data.meshes.new(name); data.from_pydata(vertices, [], faces); data.update()
    bm = bmesh.new(); bm.from_mesh(data); bmesh.ops.recalc_face_normals(bm, faces=list(bm.faces)); bm.to_mesh(data); bm.free()
    ob = bpy.data.objects.new(name, data); template.objects.link(ob)
    for p in data.polygons: p.use_smooth = smooth
    ob.data.materials.append(material); ob['role'] = role; ob['kind'] = kind; ob['evidence'] = 'photo-fitted; dimensions estimated'
    return ob

def lathe(name, profile, material, role='fixed', kind='exterior', n=64):
    vs = [(r*math.cos(i*2*PI/n),r*math.sin(i*2*PI/n),z) for r,z in profile for i in range(n)]
    fs = []
    for j in range(len(profile)):
        for i in range(n): fs.append((j*n+i,j*n+(i+1)%n,((j+1)%len(profile))*n+(i+1)%n,((j+1)%len(profile))*n+i))
    return mesh(name,vs,fs,material,role,kind)

def cyl(name, a, b, radius, material, role='fixed', kind='exterior', n=32):
    a,b = Vector(a),Vector(b); d=b-a
    bpy.ops.mesh.primitive_cylinder_add(vertices=n, radius=radius, depth=d.length, location=(a+b)/2)
    ob=bpy.context.object; ob.name=name; ob.rotation_euler=d.to_track_quat('Z','Y').to_euler()
    bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
    register(ob,material,role,kind)
    for p in ob.data.polygons: p.use_smooth=len(p.vertices)==4
    return ob

def box(name, center, size, material, role='fixed', kind='exterior', bevel=.003):
    bpy.ops.mesh.primitive_cube_add(size=1,location=center);ob=bpy.context.object;ob.name=name;ob.scale=size
    bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);register(ob,material,role,kind)
    if bevel:
        mod=ob.modifiers.new('Cantos redondeados','BEVEL');mod.width=bevel;mod.segments=2
    return ob

def torus(name,r,z,minor,material,role='fixed',kind='exterior'):
    bpy.ops.mesh.primitive_torus_add(major_radius=r,minor_radius=minor,major_segments=96,minor_segments=8,location=(0,0,z))
    ob=bpy.context.object;ob.name=name;register(ob,material,role,kind)
    for p in ob.data.polygons:p.use_smooth=True
    return ob

def pipe(name,points,r,material,role='fixed',kind='exterior'):
    curve=bpy.data.curves.new(name,'CURVE');curve.dimensions='3D';curve.resolution_u=2;curve.bevel_depth=r;curve.bevel_resolution=2
    s=curve.splines.new('POLY');s.points.add(len(points)-1)
    for p,co in zip(s.points,points):p.co=(*co,1)
    ob=bpy.data.objects.new(name,curve);template.objects.link(ob);ob.data.materials.append(material);ob['role']=role;ob['kind']=kind;return ob

def drilled(ob, z, radius=.188, holes=8):
    for i in range(holes):
        t=(i+.5)*2*PI/holes
        cutter=cyl('corte auxiliar',(radius*math.cos(t),radius*math.sin(t),z-.03),(radius*math.cos(t),radius*math.sin(t),z+.03),.005,black)
        mod=ob.modifiers.new('Taladro de fijación','BOOLEAN');mod.operation='DIFFERENCE';mod.object=cutter
        bpy.context.view_layer.objects.active=ob;bpy.ops.object.modifier_apply(modifier=mod.name);bpy.data.objects.remove(cutter,do_unlink=True)

# Housing: white outer barrel, bronze-looking wet interior, distinct seat and two
# observed sealing rings. No brand name or unsupported alloy is stamped on it.
body=lathe('Carcasa blanca hueca',[(.145,.025),(.158,.05),(.158,.652),(.151,.672),(.133,.672),(.133,.05)],white)
body.data.materials.append(bronze)
for p in body.data.polygons:
    c=p.center
    if math.hypot(c.x,c.y)<.14:p.material_index=1
cyl('Fondo de carcasa',(0,0,.025),(0,0,.042),.145,bronze)
flange=lathe('Brida superior y asiento de cesto',[(.131,.653),(.205,.653),(.205,.690),(.131,.690)],bronze,n=96);drilled(flange,.675)
torus('Junta interior observada',.142,.691,.0022,black)
torus('Junta exterior observada',.172,.691,.0022,black)
for side in [-1,1]:
    cyl('Boca de conexión '+str(side),(side*.142,0,.235),(side*.245,0,.235),.056,white)
    ob=cyl('Brida conexión '+str(side),(side*.232,0,.235),(side*.252,0,.235),.080,white)
    cyl('Cuerpo mariposa '+str(side),(side*.253,0,.235),(side*.284,0,.235),.074,blue)
    for i in range(4):
        t=(i+.5)*PI/2;cyl('Tornillo brida '+str(side)+' '+str(i),(side*.248,.068*math.cos(t),.235+.068*math.sin(t)),(side*.290,.068*math.cos(t),.235+.068*math.sin(t)),.004,steel,n=6)
    box('Palanca mariposa '+str(side),(side*.276,.078,.265),(.035,.20,.018),valve)
    cyl('Tubo adyacente '+str(side),(side*.285,0,.235),(side*.40,0,.235),.056,white)
    pipe('Retorno local de tubería '+str(side),[(side*.40,0,.235),(side*.43,0,.275),(side*.43,0,.40)],.056,white)
    for y in [-.09,.09]:box('Apoyo de carcasa '+str(side)+str(y),(side*.10,y,.018),(.07,.05,.036),white)
pipe('Cable de unión equipotencial',[(.16,.06,.18),(.18,.07,.15),(.20,.09,.04),(.28,.13,.02)],.004,green)
pipe('Banda amarilla de unión',[(.163,.063,.18),(.183,.073,.15),(.203,.093,.04),(.283,.133,.02)],.0015,yellow)
cyl('Drenaje de carcasa',(.10,.12,.07),(.10,.15,.07),.011,bronze,n=6)

lid=cyl('Tapa blanca desmontable',(0,0,.695),(0,0,.714),.205,white,'lid',n=96);drilled(lid,.704)
for i in range(8):
    t=(i+.5)*PI/4;x=.188*math.cos(t);y=.188*math.sin(t)
    cyl('Fijación tapa '+str(i),(x,y,.714),(x,y,.724),.008,white,'lid',n=6)
cyl('Tapón hexagonal de purga',(.060,0,.714),(.060,0,.738),.014,bronze,'lid',n=6)
box('Pequeña palanca roja de tapa',(-.045,0,.735),(.095,.012,.009),red,'lid',bevel=.004)

# Real octagonal openings, staggered in the cylindrical sheet. Full native
# thickness remains in Blender; the web LOD retains the perforated front sheet
# and uses double-sided shading, plus the separate thick rolled lips.
cols,rows=160,120;pitch_z=.600/rows;pitch_u=2*PI*.120/cols;hole=.0014
vs=[];fs=[]
for row in range(rows):
    zc=.050+(row+.5)*pitch_z
    for col in range(cols):
        uc=(col+.5+(row%2)*.5)*pitch_u
        boundary=[(-.5,-.5),(0,-.5),(.5,-.5),(.5,0),(.5,.5),(0,.5),(-.5,.5),(-.5,0)]
        # Same angular order for cell boundary and hole.
        inner=[(math.cos(-3*PI/4+i*PI/4)*hole,math.sin(-3*PI/4+i*PI/4)*hole)for i in range(8)]
        start=len(vs)
        for u,z in [(u*pitch_u,z*pitch_z)for u,z in boundary]+inner:
            t=(uc+u)/.120;vs.append((.120*math.cos(t),.120*math.sin(t),zc+z))
        for i in range(8):fs.append((start+i,start+(i+1)%8,start+8+(i+1)%8,start+8+i))
sheet=mesh('Cesto | chapa con 19200 perforaciones reales',vs,fs,steel,'basket','inspection')
solid=sheet.modifiers.new('Espesor nativo de chapa 0.8 mm','SOLIDIFY');solid.thickness=.0008;solid.offset=-1
sheet['web_disable_solidify']=True;sheet['hole_count']=cols*rows
lathe('Cesto | pestaña superior',[(.116,.643),(.132,.643),(.132,.651),(.116,.651)],steel,'basket','inspection',96)
torus('Cesto | labio inferior',.120,.051,.002,steel,'basket','inspection')
cyl('Cesto | fondo',(0,0,.048),(0,0,.050),.120,steel,'basket','inspection',64)
pipe('Cesto | asa transversal',[(0,-.116,.645),(0,-.103,.664),(0,.103,.664),(0,.116,.645)],.0045,steel,'basket','inspection')
box('Cesto | costura longitudinal',(.120,0,.350),(.001,.004,.600),steel,'basket','inspection',0)

# Encrustation is an illustrative alternate state derived from the dirty photo,
# not an assessment of the present condition of either installed strainer.
vs=[];fs=[];n,m=128,96
for row in range(m+1):
    z=.048+.605*row/m
    for col in range(n):
        t=col*2*PI/n;r=.123+.0014*math.sin(t*71+row*2.9)+.0018*math.cos(t*111-row*.8)
        vs.append((r*math.cos(t),r*math.sin(t),z))
for row in range(m):
    for col in range(n):fs.append((row*n+col,row*n+(col+1)%n,(row+1)*n+(col+1)%n,(row+1)*n+col))
mesh('Incrustación | funda que obstruye perforaciones',vs,fs,dirt,'basket','inspection')
inner=[(x*.943,y*.943,z)for x,y,z in vs]
mesh('Incrustación | cara interior del cesto',inner,[tuple(reversed(f))for f in fs],dirt,'basket','inspection')
lathe('Incrustación | borde superior',[(.114,.643),(.134,.643),(.135,.656),(.113,.656)],dirt,'basket','inspection',128)
for ob in template.objects:
    ob['variant']='dirty' if ob.name.startswith('Incrustación')else'clean'
    if ob['variant']=='dirty':ob.hide_render=True

# Saved native translations, sampled later for runtime and pose verification.
for ob in template.objects:
    role=ob.get('role');base=ob.location.copy()
    if role not in ['lid','basket']:continue
    for frame,delta in ([(1,(0,0,0)),(16,(0,0,.16)),(43,(-.45,0,.16)),(121,(-.45,0,.16))]if role=='lid'else[(1,(0,0,0)),(43,(0,0,0)),(121,(0,0,.70))]):
        ob.location=base+Vector(delta);ob.keyframe_insert('location',frame=frame)
    for fc in ob.animation_data.action.fcurves:
        for key in fc.keyframe_points:key.interpolation='LINEAR'
scene.frame_set(1)

def export(kind):
    attrs={n:array.array('f')for n in ['position','normal','color','surface']};indices=array.array('I');parts=[]
    dg=bpy.context.evaluated_depsgraph_get()
    for ob in sorted(template.objects,key=lambda o:o.name):
        if ob.get('kind')!=kind:continue
        mods=[mod for mod in ob.modifiers if mod.type=='SOLIDIFY'and ob.get('web_disable_solidify')]
        for mod in mods:mod.show_viewport=False
        bpy.context.view_layer.update();eo=ob.evaluated_get(dg);geo=eo.to_mesh();geo.calc_loop_triangles()
        start=len(indices);remap={};matrix=ob.matrix_world;normal=matrix.to_3x3().inverted().transposed()
        for tri in geo.loop_triangles:
            local=[]
            for li in tri.loops:
                loop=geo.loops[li];p=matrix@geo.vertices[loop.vertex_index].co;n=(normal@geo.corner_normals[li].vector).normalized()
                material=geo.materials[tri.material_index]if geo.materials else white;color=material.diffuse_color[:3];rough=material.get('roughness',.4);metal=material.get('metalness',0)
                if material==dirt:
                    grain=.78+.22*math.sin(p.x*1700+p.y*1100+p.z*1900);color=tuple(c*grain for c in color)
                key=tuple(round(v,7)for v in [*p,*n,*color,rough,metal])
                if key not in remap:
                    remap[key]=len(attrs['position'])//3
                    for name,data in [('position',p),('normal',n),('color',color),('surface',(rough,metal))]:attrs[name].extend(data)
                local.append(remap[key])
            indices.extend(local)
        parts.append({'name':ob.name,'start':start,'count':len(indices)-start,'role':ob['role'],'variant':ob['variant']})
        eo.to_mesh_clear()
        for mod in mods:mod.show_viewport=True
    blob=bytearray();views={}
    for name,data in [*attrs.items(),('indices',indices)]:
        views[name]={'offset':len(blob),'count':len(data),'type':'u32'if name=='indices'else'f32'};blob.extend(data.tobytes())
    meta={'version':VERSION,'kind':kind,'units':'metres','binary':kind+'.bin.gz','byteLength':len(blob),'sha256':hashlib.sha256(blob).hexdigest(),'vertices':len(attrs['position'])//3,'triangles':len(indices)//3,'views':views,'parts':parts,'dimensionStatus':'image-estimated','manufacturer':None}
    (out/(kind+'.json')).write_text(json.dumps(meta,ensure_ascii=False,separators=(',',':'))+'\n')
    (out/meta['binary']).write_bytes(gzip.compress(bytes(blob),compresslevel=9,mtime=0))
    return meta

exports={kind:export(kind)for kind in ['exterior','inspection']}
samples=[]
for frame in range(1,122):
    scene.frame_set(frame);row={}
    for role in ['lid','basket']:
        ob=next(o for o in template.objects if o['role']==role);base=ob.location.copy();scene.frame_set(1);origin=ob.location.copy();scene.frame_set(frame);row[role]=list(base-origin)
    samples.append(row)
poses={'version':VERSION,'fps':30,'frames':121,'duration':4,'samples':samples,'basis':'Saved Blender F-curves; illustrative disassembly, not a real servicing procedure'}
(out/'motion.json').write_text(json.dumps(poses,separators=(',',':'))+'\n')
scene.frame_set(1)

# Separate native scene with both linked sets installed at the digital source
# placement, in physical metres. Template meshes are shared, never mirrored.
installed=bpy.data.scenes.new('02 INSTALADO | dos conjuntos');installed.unit_settings.system='METRIC';installed.render.fps=30
for side,sign in [('Babor',1),('Estribor',-1)]:
    root=bpy.data.objects.new(side,None);installed.collection.objects.link(root);root.location=(12.14*(35.23/36),sign*.27*(7.47/7.6),.77)
    for ob in template.objects:
        copy=ob.copy();copy.data=ob.data;installed.collection.objects.link(copy);copy.parent=root
scene['dimensions_estimated_metres']=json.dumps({'bodyDiameter':.316,'lidDiameter':.410,'basketDiameter':.240,'basketHeight':.600,'housingHeight':.724,'basketLift':.700})
scene['maintenance']='Reusable sea-water basket. Identify OEM before applying intervals, torque or chemicals. No duplex operation claimed.'
text=bpy.data.texts.new('LEEME | fuentes y supuestos');text.write(__doc__+'\n'+scene['basis']+'\n'+scene['dimensions_estimated_metres']+'\n'+scene['maintenance'])
bpy.context.window.scene=scene;scene.frame_set(1)
bpy.ops.wm.save_as_mainfile(filepath=str(blend))
report={'version':VERSION,'blend':blend.name,'blendSHA256':hashlib.sha256(blend.read_bytes()).hexdigest(),'blender':bpy.app.version_string,'templateObjects':len(template.objects),'realPerforations':cols*rows,'dimensions':json.loads(scene['dimensions_estimated_metres']),'exports':{k:{'triangles':v['triangles'],'bytes':v['byteLength'],'compressedBytes':(out/v['binary']).stat().st_size}for k,v in exports.items()},'privateMediaPublished':False,'manufacturerIdentified':False}
(out/'export-report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2),flush=True)

if opt.render_dir:
    target=Path(opt.render_dir);target.mkdir(parents=True,exist_ok=True)
    scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=24;scene.cycles.use_denoising=False
    scene.render.resolution_x=900;scene.render.resolution_y=1000;scene.render.resolution_percentage=100
    scene.world=bpy.data.worlds.new('Luz neutra de taller');scene.world.use_nodes=True;scene.world.node_tree.nodes['Background'].inputs[0].default_value=(.45,.48,.50,1);scene.world.node_tree.nodes['Background'].inputs[1].default_value=.45
    for location,power,size in [((1,-1,2),170,2),((-1,0,1.3),110,1.5),((0,1,1.8),180,1.5)]:
        data=bpy.data.lights.new('Luz de estudio','AREA');data.energy=power;data.shape='DISK';data.size=size
        ob=bpy.data.objects.new('Luz de estudio',data);scene.collection.objects.link(ob);ob.location=location;ob.rotation_euler=(Vector((0,0,.45))-ob.location).to_track_quat('-Z','Y').to_euler()
    cam=bpy.data.objects.new('Cámara',bpy.data.cameras.new('Cámara'));scene.collection.objects.link(cam);scene.camera=cam;cam.data.lens=55
    for name,frame,dirty_state,position,look in [('conjunto',1,False,(1.25,-1.4,1.45),(0,0,.40)),('cesto-limpio',121,False,(1.15,-1.35,1.6),(0,0,.85)),('cesto-sucio',121,True,(1.15,-1.35,1.6),(0,0,.85))]:
        scene.frame_set(frame)
        for ob in template.objects:
            if ob.get('variant')=='dirty':ob.hide_render=not dirty_state
        cam.location=position;cam.rotation_euler=(Vector(look)-cam.location).to_track_quat('-Z','Y').to_euler();scene.render.filepath=str(target/(name+'.png'));bpy.ops.render.render(write_still=True)
