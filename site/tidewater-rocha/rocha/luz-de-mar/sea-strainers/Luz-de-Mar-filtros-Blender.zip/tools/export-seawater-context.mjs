// Export the exact runtime well, inferred headers and adjacent floor/guards for
// the native Blender installation scene. No owner imagery is embedded.
import {readFileSync,writeFileSync} from 'node:fs';
import {validateLuzDeMarAsset} from '../../src/world/yacht/LuzDeMar.js';
import {createEntranceYacht} from '../../src/world/rocha/RochaEntranceYacht.js';
const root=new URL('../../public/',import.meta.url),bytes=readFileSync(new URL('rocha/luz-de-mar/model.bin',root));
const asset=validateLuzDeMarAsset(JSON.parse(readFileSync(new URL('rocha/luz-de-mar/model.json',root))),bytes.buffer.slice(bytes.byteOffset,bytes.byteOffset+bytes.byteLength));
const m=createEntranceYacht(JSON.parse(readFileSync(new URL('rocha/rocha-data.json',root))),asset,{seaStrainerOptions:{fetcher:async u=>new Response(readFileSync(new URL(u.replace(/^\.\//,''),root)))}});
if(!await m.strainers.loadExterior())throw Error(m.strainers.state.error);
const g=m.strainers.fitting.geometry,parts=[{name:'Foso y conexiones inferidas | geometría del software',vertices:[],indices:Array.from(g.index.array),colors:Array.from(g.getAttribute('color').array),surface:Array.from(g.getAttribute('aSeaSurface').array)}];
const p=g.getAttribute('position').array;
for(let i=0;i<p.length;i+=3)parts[0].vertices.push(p[i+2]+35.23/2,p[i],p[i+1]+2.01);
for(const part of m.machinery.parts){
 if(!((part.system==='floor'&&part.bounds[0]<13&&part.bounds[3]>10.8&&part.bounds[1]>=-.5&&part.bounds[4]<=.5)||part.feature.includes('guard upright')||part.feature.includes('continuous polished engine safety guard')))continue;
 const color=part.finish[0],srgb=[(color>>16&255)/255,(color>>8&255)/255,(color&255)/255],linear=srgb.map(c=>c<=.04045?c/12.92:((c+.055)/1.055)**2.4);
 const vertices=[];for(let i=0;i<part.vertices.length;i+=6)vertices.push(part.vertices[i]*35.23/36,part.vertices[i+1]*7.47/7.6,part.vertices[i+2]);
 parts.push({name:part.feature,vertices,indices:part.indices,color:linear,surface:part.finish.slice(1,3),removable:m.machinery.seaStrainerAccess.panelIds.includes(part.id)});
}
writeFileSync(process.argv[2]||'results/luz-seawater-filters/installation-context.json',JSON.stringify({units:'physical metres',dimensions:'estimated',parts}));
console.log(`Exported ${parts.length} installation context meshes`);m.dispose();
