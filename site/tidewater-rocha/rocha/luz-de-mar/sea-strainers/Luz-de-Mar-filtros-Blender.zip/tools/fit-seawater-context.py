"""Append the exported runtime installation context to scene 02, then save.
blender -b MODEL.blend -Y --python fit-seawater-context.py -- --context JSON --report JSON
"""
import argparse,hashlib,json,sys
from pathlib import Path
import bpy
ap=argparse.ArgumentParser();ap.add_argument('--context',required=True);ap.add_argument('--report',required=True);args=ap.parse_args(sys.argv[sys.argv.index('--')+1:])
data=json.loads(Path(args.context).read_text());scene=bpy.data.scenes['02 INSTALADO | dos conjuntos'];bpy.context.window.scene=scene
collection=bpy.data.collections.new('CONTEXTO | ajuste digital estimado');scene.collection.children.link(collection)
palette={}
def material(color,surface):
 key=tuple(round(x,4)for x in [*color,*surface])
 if key not in palette:
  mat=bpy.data.materials.new('Contexto '+str(len(palette)));mat.diffuse_color=(*color,1);mat.use_nodes=True;s=mat.node_tree.nodes['Principled BSDF'];s.inputs['Base Color'].default_value=(*color,1);s.inputs['Roughness'].default_value=surface[0];s.inputs['Metallic'].default_value=surface[1];palette[key]=mat
 return palette[key]
for p in data['parts']:
 vertices=[p['vertices'][i:i+3]for i in range(0,len(p['vertices']),3)];faces=[p['indices'][i:i+3]for i in range(0,len(p['indices']),3)]
 mesh=bpy.data.meshes.new(p['name']);mesh.from_pydata(vertices,[],faces);mesh.update();ob=bpy.data.objects.new(p['name'],mesh);collection.objects.link(ob);ob['evidence']='Exact digital fit from runtime. Hidden connections and dimensions estimated.'
 slots={}
 for face in mesh.polygons:
  i=face.vertices[0];color=p['colors'][i*3:i*3+3]if'colors'in p else p['color'];surface=p['surface'][i*2:i*2+2]if'colors'in p else p['surface'];mat=material(color,surface)
  if mat.name not in slots:slots[mat.name]=len(mesh.materials);mesh.materials.append(mat)
  face.material_index=slots[mat.name]
 if p.get('removable'):
  for frame,hidden in [(1,False),(2,True),(121,True)]:
   ob.hide_render=hidden;ob.hide_viewport=hidden;ob.keyframe_insert('hide_render',frame=frame);ob.keyframe_insert('hide_viewport',frame=frame)
scene.frame_start=1;scene.frame_end=121;scene['context']='Runtime-derived well, pipes, floor and rails. Floor closes at frame 1 and opens at frame 2. Not surveyed CAD.';scene.frame_set(1)
bpy.context.window.scene=bpy.data.scenes['01 CONJUNTO | escala estimada'];bpy.context.scene.frame_set(1)
bpy.ops.wm.save_as_mainfile(filepath=bpy.data.filepath)
report=Path(args.report);r=json.loads(report.read_text());r['blendSHA256']=hashlib.sha256(Path(bpy.data.filepath).read_bytes()).hexdigest();r['installedContextMeshes']=len(data['parts']);report.write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'contextMeshes':len(data['parts']),'blendSHA256':r['blendSHA256']}))
