"""Render the saved .blend without rebuilding its geometry."""
import argparse,sys
from pathlib import Path
import bpy
from mathutils import Vector
args=argparse.ArgumentParser();args.add_argument('--out',required=True);opt=args.parse_args(sys.argv[sys.argv.index('--')+1:]);out=Path(opt.out);out.mkdir(parents=True,exist_ok=True)
scene=bpy.data.scenes['01 CONJUNTO | escala estimada'];bpy.context.window.scene=scene
scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=32;scene.cycles.use_denoising=False
scene.render.resolution_x=780;scene.render.resolution_y=900;scene.render.resolution_percentage=100
scene.world=bpy.data.worlds.new('Taller neutro');scene.world.use_nodes=True;scene.world.node_tree.nodes['Background'].inputs[0].default_value=(.45,.48,.50,1);scene.world.node_tree.nodes['Background'].inputs[1].default_value=.45
for location,power,size in [((1,-1,2),170,2),((-1,0,1.3),110,1.5),((0,1,1.8),180,1.5)]:
 data=bpy.data.lights.new('Luz de estudio','AREA');data.energy=power;data.shape='DISK';data.size=size;ob=bpy.data.objects.new('Luz de estudio',data);scene.collection.objects.link(ob);ob.location=location;ob.rotation_euler=(Vector((0,0,.45))-ob.location).to_track_quat('-Z','Y').to_euler()
cam=bpy.data.objects.new('Cámara',bpy.data.cameras.new('Cámara'));scene.collection.objects.link(cam);scene.camera=cam;cam.data.lens=60
for name,frame,dirty,position,look in [('conjunto',1,False,(1.25,-1.4,1.45),(0,0,.40)),('cesto-limpio',121,False,(1.15,-1.35,1.65),(0,0,.84)),('cesto-sucio',121,True,(1.15,-1.35,1.65),(0,0,.84))]:
 scene.frame_set(frame)
 for ob in scene.objects:
  if ob.get('variant')=='dirty':ob.hide_render=not dirty
 cam.location=position;cam.rotation_euler=(Vector(look)-cam.location).to_track_quat('-Z','Y').to_euler();scene.render.filepath=str(out/(name+'.png'));bpy.ops.render.render(write_still=True)
