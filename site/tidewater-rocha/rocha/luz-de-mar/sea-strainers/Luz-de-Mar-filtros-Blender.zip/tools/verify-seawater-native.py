"""Independently compare all saved native poses with the exported motion file."""
import argparse,json,sys
from pathlib import Path
import bpy
args=argparse.ArgumentParser();args.add_argument('--assets',required=True);args.add_argument('--report',required=True)
opt=args.parse_args(sys.argv[sys.argv.index('--')+1:]);data=json.loads((Path(opt.assets)/'motion.json').read_text());scene=bpy.data.scenes['01 CONJUNTO | escala estimada'];bpy.context.window.scene=scene;scene.frame_set(1)
objects=[o for o in scene.objects if o.get('role')in['lid','basket']];origins={o.name:o.matrix_world.translation.copy()for o in objects};maximum=0;comparisons=0
for i in range(121):
 scene.frame_set(i+1);bpy.context.view_layer.update()
 for ob in objects:
  actual=ob.matrix_world.translation-origins[ob.name];exported=data['samples'][i][ob['role']]
  maximum=max(maximum,max(abs(actual[j]-exported[j])for j in range(3)));comparisons+=1
report={'frames':121,'objects':len(objects),'poseComparisons':comparisons,'maxTranslationErrorMetres':maximum,'pass':maximum<1e-6,'scope':'Digital export agreement, not physical installation accuracy'}
Path(opt.report).write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report));assert report['pass']
