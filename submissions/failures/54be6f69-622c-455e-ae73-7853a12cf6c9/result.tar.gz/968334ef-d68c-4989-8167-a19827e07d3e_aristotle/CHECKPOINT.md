# CHECKPOINT — CONTINUE

This is a compiling but incomplete proof-development checkpoint. It is **not** a completed formalization of the claimed partition theorem.

## Completed, compiler-checked work

- `RequestProject/Definitions.lean`
  - Defines nonempty perimeter-`n` partitions as bounded multiplicity profiles.
  - Uses the convention `largest part + number of parts - 1 = n`.
  - Defines `divPresent`, `repeatedSizes`, `FO`, and `FD`.
  - Includes `native_decide` checks that the first profile counts are `1,2,4,8,16` and checks several `k=2` count equalities.
- `RequestProject/Roots.lean`
  - Defines the real denominator functions `AD` and `AO`.
  - Proves existence and uniqueness of their positive roots in `(1/2,1)`.
  - Defines `rhoD` and `rhoO`, proves their root properties, proves the denominator difference identity, and proves `rhoD k < rhoO k` for `k ≥ 3`.

## Exact unresolved Lean goals

### 1. Exact `k=2` equality

File: `RequestProject/EqualityTwo.lean`, theorem `counts_equal_two` (currently line 8):

```lean
theorem counts_equal_two (j n : ℕ) : FO j 2 n = FD j 2 n := by
  sorry
```

A direct automated attempt on the cardinality-level statement did not close it. The next action should be to define an explicit statistic-preserving bijection on multiplicity profiles (or first derive equal finite generating polynomials by induction on perimeter), then obtain the cardinality equality from that reusable lemma.

### 2. Ratio limit

File: `RequestProject/Final.lean`, theorem `ratio_tendsto_zero` (currently line 13):

```lean
theorem ratio_tendsto_zero (j k : ℕ) (hk : 3 ≤ k) :
    Tendsto (fun n : ℕ => (FO j k n : ℝ) / (FD j k n : ℝ)) atTop (𝓝 0) := by
  sorry
```

Before proving this, the following missing bridge must be implemented:

1. Derive fixed-`j` coefficient recurrences/generating-function identities directly from `Profile`.
2. Prove the complex minimum-modulus uniqueness statements for the zeros of the corresponding polynomials (only the positive-real root theory is presently formalized).
3. Establish claim-specific coefficient upper and lower bounds (or formal rational asymptotics), including noncancellation and positivity of the dominant coefficient.
4. Apply `roots_strict_order` to obtain exponential decay of the quotient.

### 3. Eventual strict inequality

File: `RequestProject/Final.lean`, theorem `eventually_strict` (currently line 18):

```lean
theorem eventually_strict (j k : ℕ) (hk : 3 ≤ k) :
    ∀ᶠ n : ℕ in atTop, FO j k n < FD j k n := by
  sorry
```

After the ratio theorem, additionally prove eventual positivity of `FD j k n`, then combine positivity, nonnegativity, and convergence of the ratio to zero (eventually ratio `< 1`).

## Approaches already attempted

- Direct closure of `counts_equal_two` from the raw finite cardinality definitions was attempted and did not converge. It should be decomposed rather than retried monolithically.
- The real-root portion was successfully decomposed into existence/uniqueness, root membership, a polynomial identity, and strict comparison.
- No unproved assumptions or project-specific axioms were added. The three declarations above still contain `sorry`, so no final axiom audit can yet pass.

## Build command

```sh
lake build
```

The project builds, with warnings identifying the three remaining `sorry` declarations.
