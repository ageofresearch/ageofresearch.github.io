import Mathlib

open scoped BigOperators

namespace FixedPerimeter

/-- A nonempty partition encoded by its largest part (minus one) and by
multiplicities at sizes `1, …, L`.  The equations say that the top
multiplicity is positive and `L + number of parts - 1 = n`. -/
def Profile (n : ℕ) :=
  {s : Σ l : Fin n, Fin (l.1 + 1) → Fin (n + 1) //
    0 < (s.2 ⟨s.1.1, Nat.lt_add_one _⟩).1 ∧
    s.1.1 + (∑ i, (s.2 i).1) = n}

deriving Fintype, DecidableEq

/-- Number of present part sizes divisible by `k`. Sizes are one-based. -/
def divPresent {n : ℕ} (k : ℕ) (p : Profile n) : ℕ :=
  ∑ i, if k ∣ i.1 + 1 ∧ 0 < (p.1.2 i).1 then 1 else 0

/-- Number of part sizes whose multiplicity is at least `k`. -/
def repeatedSizes {n : ℕ} (k : ℕ) (p : Profile n) : ℕ :=
  ∑ i, if k ≤ (p.1.2 i).1 then 1 else 0

/-- `FO(j,k,n)` from the conversation, with nonempty partitions and perimeter `n`. -/
def FO (j k n : ℕ) : ℕ :=
  Fintype.card {p : Profile n // divPresent k p = j}

/-- `FD(j,k,n)` from the conversation, with nonempty partitions and perimeter `n`. -/
def FD (j k n : ℕ) : ℕ :=
  Fintype.card {p : Profile n // repeatedSizes k p = j}

/-- Finite enumeration agrees with the expected total `2^(n-1)` for the first
few positive perimeters. This validates the boundary conventions. -/
theorem profile_card_small :
    Fintype.card (Profile 1) = 1 ∧
    Fintype.card (Profile 2) = 2 ∧
    Fintype.card (Profile 3) = 4 ∧
    Fintype.card (Profile 4) = 8 ∧
    Fintype.card (Profile 5) = 16 := by native_decide

/-- Small exact checks of both statistics and the `k=2` identity. -/
theorem counts_small_k2 :
    (∀ j ≤ 4, FO j 2 4 = FD j 2 4) ∧
    (∀ j ≤ 5, FO j 2 5 = FD j 2 5) := by native_decide

end FixedPerimeter
