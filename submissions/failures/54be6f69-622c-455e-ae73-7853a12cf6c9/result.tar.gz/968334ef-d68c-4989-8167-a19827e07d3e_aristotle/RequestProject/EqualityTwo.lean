import RequestProject.Definitions

namespace FixedPerimeter

/-- The exact `k=2` case: at each perimeter, the distribution of the number of
even part sizes present equals the distribution of the number of repeated part
sizes. -/
theorem counts_equal_two (j n : ℕ) : FO j 2 n = FD j 2 n := by
  sorry

end FixedPerimeter
