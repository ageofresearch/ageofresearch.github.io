import RequestProject.Definitions
import RequestProject.EqualityTwo
import RequestProject.Roots

open Filter
open Topology

namespace FixedPerimeter

/-- The claimed asymptotic statement, interpreted in `ℝ`; division by zero at
finitely many initial indices uses the field convention and does not affect the
limit. -/
theorem ratio_tendsto_zero (j k : ℕ) (hk : 3 ≤ k) :
    Tendsto (fun n : ℕ => (FO j k n : ℝ) / (FD j k n : ℝ)) atTop (𝓝 0) := by
  sorry

/-- The strengthened eventual strict inequality. -/
theorem eventually_strict (j k : ℕ) (hk : 3 ≤ k) :
    ∀ᶠ n : ℕ in atTop, FO j k n < FD j k n := by
  sorry

end FixedPerimeter
