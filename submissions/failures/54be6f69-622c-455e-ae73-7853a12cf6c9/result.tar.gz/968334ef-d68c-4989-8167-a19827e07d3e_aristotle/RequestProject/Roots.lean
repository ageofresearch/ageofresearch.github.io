import Mathlib

namespace FixedPerimeter

noncomputable section

/-- The denominator factor governing `FD`. -/
def AD (k : ℕ) (x : ℝ) : ℝ := 1 - ∑ i ∈ Finset.Icc 1 k, x ^ i

/-- The denominator factor governing `FO`. -/
def AO (k : ℕ) (x : ℝ) : ℝ := (1 - x) ^ (k - 1) - x ^ k

lemma existsUnique_AD_root (k : ℕ) (hk : 2 ≤ k) :
    ∃! x : ℝ, x ∈ Set.Ioo (1 / 2 : ℝ) 1 ∧ AD k x = 0 := by
  -- AD k x = 1 - ∑ i ∈ Finset.Icc 1 k, x ^ i
  -- Define f(x) = -AD k x = ∑ i ∈ Finset.Icc 1 k, x ^ i - 1
  -- We need f(x) = 0, i.e., ∑ i ∈ Finset.Icc 1 k, x ^ i = 1
  -- f is strictly increasing, f(1/2) < 0, f(1) > 0
  let f : ℝ → ℝ := fun x => ∑ i ∈ Finset.Icc 1 k, x ^ i
  have hf_cont : Continuous f := by continuity
  have hf_mono : StrictMonoOn f (Set.Ioo (1/2 : ℝ) 1) := fun x hx y hy hxy => by
    simp only [f]
    have hx_pos : 0 ≤ x := by linarith [hx.1]
    have h : ∑ i ∈ Finset.Icc 1 k, x ^ i < ∑ i ∈ Finset.Icc 1 k, y ^ i := by
      apply Finset.sum_lt_sum
      · intro i hi
        exact pow_le_pow_left₀ hx_pos (le_of_lt hxy) _
      · exact ⟨1, Finset.mem_Icc.mpr ⟨by norm_num, by omega⟩, pow_lt_pow_left₀ hxy (by linarith [hx.1]) (by norm_num)⟩
    exact h
  -- f(1/2) = 1 - (1/2)^k < 1
  have hf_half : f (1/2) = 1 - (1/2 : ℝ)^k := by
    simp only [f]
    have h1 : ∑ i ∈ Finset.Icc 1 k, (1/2 : ℝ)^i = ∑ i ∈ Finset.range k, (1/2 : ℝ)^(i+1) := by
      have h2 : Finset.Icc 1 k = Finset.Ico 1 (k + 1) := by
        ext; simp
      rw [h2, Finset.sum_Ico_eq_sum_range]
      simp [add_comm]
    rw [h1]
    have hsum : ∑ i ∈ Finset.range k, (1/2 : ℝ)^(i+1) = (1/2) * ∑ i ∈ Finset.range k, (1/2 : ℝ)^i := by
      simp [pow_succ, mul_comm, Finset.mul_sum]
    rw [hsum]
    have hgeom : ∑ i ∈ Finset.range k, (1/2 : ℝ)^i = (1 - (1/2 : ℝ)^k) / (1 - 1/2) := by
      rw [geom_sum_eq] <;> norm_num
      field_simp
      ring
    rw [hgeom]
    ring
  have hf_half_lt : f (1/2) < 1 := by rw [hf_half]; exact sub_lt_self _ (by positivity)
  -- f(1) = k ≥ 2 > 1
  have hf_one : f 1 = (k : ℝ) := by
    simp only [f]
    have : Finset.card (Finset.Icc 1 k) = k := by simp
    simp [Finset.sum_const, nsmul_eq_mul, this]
  have hf_one_gt : f 1 > 1 := by rw [hf_one]; exact_mod_cast hk
  -- Use IVT: f(1/2) < 1 < f(1), so there exists c ∈ (1/2, 1) with f(c) = 1
  have h_half_le_one : (1/2 : ℝ) ≤ 1 := by norm_num
  have hfIcc : ContinuousOn f (Set.Icc (1/2 : ℝ) 1) := hf_cont.continuousOn
  have hf_maps : Set.Icc (f (1/2)) (f 1) ⊆ f '' Set.Icc (1/2 : ℝ) 1 :=
    intermediate_value_Icc h_half_le_one hfIcc
  have h1_mem : (1 : ℝ) ∈ Set.Icc (f (1/2)) (f 1) := by
    constructor <;> linarith [hf_half_lt, hf_one_gt]
  obtain ⟨c, hc_mem, hc_eq⟩ := hf_maps h1_mem
  -- c ≠ 1/2 since f(1/2) < 1
  have hc_ne_half : c ≠ 1/2 := by
    intro h
    rw [h] at hc_eq
    linarith [hf_half_lt]
  -- c ≠ 1 since f(1) > 1
  have hc_ne_one : c ≠ 1 := by
    intro h
    rw [h] at hc_eq
    linarith [hf_one_gt]
  have hc_mem' : c ∈ Set.Ioo (1/2 : ℝ) 1 := ⟨lt_of_le_of_ne hc_mem.1 hc_ne_half.symm, lt_of_le_of_ne hc_mem.2 hc_ne_one⟩
  -- AD k c = 0 since f c = 1
  have hc_AD : AD k c = 0 := by unfold AD; linarith
  -- Existence
  use c
  constructor
  · exact ⟨hc_mem', hc_AD⟩
  · -- Uniqueness
    intro y ⟨hy_mem, hy_AD⟩
    unfold AD at hy_AD
    have hy_f : f y = 1 := by linarith
    exact hf_mono.eq_iff_eq hy_mem hc_mem' |>.mp (by linarith)

lemma existsUnique_AO_root (k : ℕ) (hk : 2 ≤ k) :
    ∃! x : ℝ, x ∈ Set.Ioo (1 / 2 : ℝ) 1 ∧ AO k x = 0 := by
  have hcont : ContinuousOn (AO k) (Set.Icc (1/2 : ℝ) 1) := by
    unfold AO
    fun_prop
  have hAO_half : AO k (1/2) > 0 := by
    unfold AO
    have h1 : (1 - (1/2 : ℝ)) ^ (k - 1) = (1/2) ^ (k - 1) := by ring
    rw [h1]
    have h2 : (1/2 : ℝ) ^ k = (1/2) ^ (k - 1) * (1/2) := by
      rw [← pow_succ, Nat.sub_add_cancel (by linarith : 1 ≤ k)]
    rw [h2]
    linarith [pow_pos (by norm_num : (0 : ℝ) < 1/2) (k - 1)]
  have hAO_one : AO k 1 < 0 := by
    unfold AO
    have hk1 : 0 < k - 1 := Nat.sub_pos_of_lt (by linarith : 1 < k)
    simp [hk1, zero_pow hk1.ne']
  -- IVT gives existence of a root in (1/2, 1)
  have hex : ∃ x ∈ Set.Ioo (1/2 : ℝ) 1, AO k x = 0 := by
    have h01 : (1:ℝ)/2 < 1 := by norm_num
    have h := intermediate_value_Ioo' (by norm_num : (1:ℝ)/2 ≤ 1) hcont
    have h0_mem : (0 : ℝ) ∈ Set.Ioo (AO k 1) (AO k (1/2)) := ⟨hAO_one, hAO_half⟩
    exact h h0_mem
  -- AO k is strictly decreasing on (0, 1)
  have hstrict : StrictAntiOn (AO k) (Set.Ioo (0:ℝ) 1) := by
    intro x hx y hy hxy
    unfold AO
    have hk' : k - 1 ≠ 0 := Nat.sub_ne_zero_of_lt (by linarith : 1 < k)
    apply sub_lt_sub
    · gcongr <;> linarith [hy.2]
    · gcongr <;> linarith [hx.1]
  -- Combine existence and uniqueness
  obtain ⟨x, hx_mem, hx_eq⟩ := hex
  have hx_mem' : x ∈ Set.Ioo (0:ℝ) 1 := ⟨by linarith [hx_mem.1], hx_mem.2⟩
  have hy_mem' : ∀ y ∈ Set.Ioo (1/2:ℝ) 1, y ∈ Set.Ioo (0:ℝ) 1 := fun y hy => ⟨by linarith [hy.1], hy.2⟩
  exact ⟨x, ⟨hx_mem, hx_eq⟩, fun y ⟨hy_mem, hy_eq⟩ => (hstrict.eq_iff_eq (hy_mem' y hy_mem) hx_mem' |>.mp (by rw [hy_eq, hx_eq])).symm⟩

/-- The positive root of `1-x-⋯-x^k`. -/
def rhoD (k : ℕ) : ℝ :=
  if hk : 2 ≤ k then Classical.choose (existsUnique_AD_root k hk) else 3 / 4

/-- The positive root of `(1-x)^(k-1)-x^k`. -/
def rhoO (k : ℕ) : ℝ :=
  if hk : 2 ≤ k then Classical.choose (existsUnique_AO_root k hk) else 3 / 4

lemma rhoD_mem (k : ℕ) (hk : 2 ≤ k) :
    rhoD k ∈ Set.Ioo (1 / 2 : ℝ) 1 ∧ AD k (rhoD k) = 0 := by
  rw [rhoD, dif_pos hk]
  exact (Classical.choose_spec (existsUnique_AD_root k hk)).1

lemma rhoO_mem (k : ℕ) (hk : 2 ≤ k) :
    rhoO k ∈ Set.Ioo (1 / 2 : ℝ) 1 ∧ AO k (rhoO k) = 0 := by
  rw [rhoO, dif_pos hk]
  exact (Classical.choose_spec (existsUnique_AO_root k hk)).1

lemma AO_sub_AD (k : ℕ) (x : ℝ) (hk : 2 ≤ k) :
    AO k x - AD k x = x * ∑ i ∈ Finset.range (k - 1), (x ^ i - (1 - x) ^ i) := by
  simp [AO, AD]
  have h1 : ∑ i ∈ Finset.Icc 1 k, x ^ i = x * ∑ i ∈ Finset.range k, x ^ i := by
    have heq : Finset.Icc 1 k = Finset.Ico 1 (k + 1) := by
      simp [Finset.ext_iff, Finset.mem_Icc, Finset.mem_Ico]
    rw [heq, Finset.sum_Ico_eq_sum_range]
    simp [pow_add, Finset.mul_sum]
  rw [h1]
  -- Now: (1 - x) ^ (k - 1) - x ^ k - (1 - x * ∑ i ∈ Finset.range k, x ^ i) = x * (∑ i ∈ Finset.range (k - 1), x ^ i - ∑ x_1 ∈ Finset.range (k - 1), (1 - x) ^ x_1)
  -- Simplify: split range k = range (k-1) ∪ {k-1}
  have h2 : ∑ i ∈ Finset.range k, x ^ i = ∑ i ∈ Finset.range (k - 1), x ^ i + x ^ (k - 1) := by
    rcases k with ⟨⟩
    · omega
    · simp [Finset.sum_range_succ]
  rw [h2]
  simp [mul_add]
  -- x * x ^ (k-1) = x ^ k
  have hx_pow : x * x ^ (k - 1) = x ^ k := by
    rcases k with ⟨⟩
    · omega
    · simp [pow_succ, mul_comm]
  rw [hx_pow]
  ring_nf
  -- Need: (1 - x) ^ (k - 1) + x * ∑ x_1 ∈ Finset.range (k - 1), (1 - x) ^ x_1 = 1
  -- This is the geometric series: r = 1 - x, so (1 - r) * ∑ r^i = 1 - r^n
  have hgeo : x * ∑ i ∈ Finset.range (k - 1), (1 - x) ^ i = 1 - (1 - x) ^ (k - 1) := by
    have := geom_sum_mul_neg (1 - x) (k - 1)
    simp at this
    linarith
  linarith [hgeo]

lemma roots_strict_order (k : ℕ) (hk : 3 ≤ k) : rhoD k < rhoO k := by
  -- Get membership facts
  have hD := rhoD_mem k (by linarith)
  have hO := rhoO_mem k (by linarith)
  -- AO k (rhoO k) = 0
  have hAO_zero : AO k (rhoO k) = 0 := hO.2
  -- AD k (rhoO k) < 0
  have hAD_neg : AD k (rhoO k) < 0 := by
    have h_diff := AO_sub_AD k (rhoO k) (by linarith)
    -- Need to show AO k (rhoO k) - AD k (rhoO k) > 0
    -- i.e., rhoO k * ∑ i ∈ Finset.range (k - 1), (rhoO k ^ i - (1 - rhoO k) ^ i) > 0
    have hx_pos : rhoO k > 0 := by linarith [hO.1.1]
    have hx_le_one : rhoO k ≤ 1 := by linarith [hO.1.2]
    have h_sum_pos : ∑ i ∈ Finset.range (k - 1), (rhoO k ^ i - (1 - rhoO k) ^ i) > 0 := by
      have hk1 : 1 < k - 1 := Nat.lt_sub_of_add_lt (by linarith : 2 + 1 ≤ k)
      have h_range_1 : 1 ∈ Finset.range (k - 1) := Finset.mem_range.mpr hk1
      calc ∑ i ∈ Finset.range (k - 1), (rhoO k ^ i - (1 - rhoO k) ^ i)
          ≥ rhoO k ^ 1 - (1 - rhoO k) ^ 1 := by
            apply Finset.single_le_sum (f := fun i => rhoO k ^ i - (1 - rhoO k) ^ i) (fun i _ => _) h_range_1
            intro i hi
            apply sub_nonneg.mpr
            gcongr
            · linarith [hO.1.1]
            · linarith [hO.1.1]
        _ = rhoO k - (1 - rhoO k) := by ring
        _ = 2 * rhoO k - 1 := by ring
        _ > 0 := by linarith [hO.1.1]
    have h_prod_pos : rhoO k * ∑ i ∈ Finset.range (k - 1), (rhoO k ^ i - (1 - rhoO k) ^ i) > 0 := by
      apply mul_pos hx_pos h_sum_pos
    linarith [h_diff, hAO_zero, h_prod_pos]
  -- AD k is strictly decreasing, so AD k (rhoO k) < 0 = AD k (rhoD k) implies rhoO k > rhoD k
  have hAD_decreasing : StrictAntiOn (AD k) (Set.Ioo (0:ℝ) 1) := by
    intro x hx y hy hxy
    unfold AD
    have hsum_lt : ∑ i ∈ Finset.Icc 1 k, x ^ i < ∑ i ∈ Finset.Icc 1 k, y ^ i := by
      apply Finset.sum_lt_sum
      · intro i hi
        exact pow_le_pow_left₀ (by linarith [hx.1]) (le_of_lt hxy) _
      · exact ⟨1, Finset.mem_Icc.mpr ⟨by norm_num, by linarith⟩, pow_lt_pow_left₀ hxy (by linarith [hx.1]) (by norm_num)⟩
    linarith
  have hD_mem' : rhoD k ∈ Set.Ioo (0:ℝ) 1 := ⟨by linarith [hD.1.1], hD.1.2⟩
  have hO_mem' : rhoO k ∈ Set.Ioo (0:ℝ) 1 := ⟨by linarith [hO.1.1], hO.1.2⟩
  apply lt_of_not_ge
  intro hle
  rcases hle.lt_or_eq with hlt | heq
  · have : AD k (rhoD k) < AD k (rhoO k) := hAD_decreasing hO_mem' hD_mem' hlt
    linarith [hD.2]
  · rw [heq] at hAD_neg
    linarith [hD.2]

end
end FixedPerimeter
