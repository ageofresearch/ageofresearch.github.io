# Formalization status and precise remaining obligations

The requested unconditional proof is **not complete**.  `RequestProject/Main.lean`
contains a faithful finite definition of nonempty perimeter partitions, the two
statistics, `FO`, and `FD`, including proofs that both counts vanish at perimeter
zero.  The following three declarations remain marked `sorry` and therefore are
not claimed as proved:

1. `PerimeterPartitions.fd_eq_fo_two`
   ```lean
   ∀ j n, FD j 2 n = FO j 2 n
   ```
   Remaining obligation: construct and verify a statistic-preserving finite
   bijection (or prove an equivalent coefficient identity) between multiplicity
   vectors of perimeter `n`, carrying the number of entries at least two to the
   number of positive entries in even-indexed part sizes.

2. `PerimeterPartitions.fo_div_fd_tendsto_zero`
   ```lean
   ∀ j k, 3 ≤ k →
     Tendsto (fun n ↦ (FO j k n : ℝ) / (FD j k n : ℝ)) atTop (𝓝 0)
   ```
   Remaining obligations: internally derive exact generating functions (or
   equivalent recurrences) for both refined counts; establish all required
   coefficient estimates for fixed `j` and `k ≥ 3`; prove eventual nonvanishing
   of the denominator; and combine these into the stated real-valued limit.
   No generating-function identity, root location, or asymptotic estimate has
   been assumed in the file.

3. `PerimeterPartitions.fo_lt_fd_eventually`
   ```lean
   ∀ j k, 3 ≤ k → ∃ N, ∀ n ≥ N, FO j k n < FD j k n
   ```
   Remaining obligations: prove eventual positivity of `FD j k n` and use the
   limit theorem (for example, an eventual bound of the quotient by `1`) to
   obtain strict inequality.  The limit alone is insufficient when the
   denominator may vanish, so this positivity step must be discharged
   separately.

The `#print axioms` commands currently display `sorryAx` for exactly these
unfinished final theorems.  Thus this project is an explicit partial
formalization and not a completed proof of the user's theorem.
