import Mathlib

open scoped BigOperators Topology
open Filter

set_option maxHeartbeats 8000000
set_option maxRecDepth 4000
set_option relaxedAutoImplicit false
set_option autoImplicit false

namespace PerimeterPartitions

/-- A nonempty integer partition represented by its multiplicities, together with a
proof that its perimeter is `n`.  The actual largest part is `largest + 1`; thus
there are multiplicities for the part sizes `1, ..., largest + 1` and the last
one is required to be positive.  Since
`perimeter = (largest + 1) + numberOfParts - 1`, the final equation is exactly
the perimeter condition.  For `n = 0` this type is empty (`Fin 0` has no term). -/
structure Partition (n : ℕ) where
  largest : Fin n
  multiplicity : Fin (largest.1 + 1) → Fin (n + 1)
  largest_present : 0 < (multiplicity ⟨largest.1, Nat.lt_succ_self _⟩).1
  perimeter_eq : largest.1 + ∑ i, (multiplicity i).1 = n
deriving Fintype, DecidableEq

/-- The number of parts, with repetitions. -/
def Partition.numberOfParts {n : ℕ} (p : Partition n) : ℕ :=
  ∑ i, (p.multiplicity i).1

/-- The (positive) largest part. -/
def Partition.largestPart {n : ℕ} (p : Partition n) : ℕ := p.largest.1 + 1

/-- The perimeter, expressed from the usual definition. -/
def Partition.perimeter {n : ℕ} (p : Partition n) : ℕ :=
  p.largestPart + p.numberOfParts - 1

@[simp] theorem Partition.perimeter_eq_index {n : ℕ} (p : Partition n) :
    p.perimeter = n := by
  unfold perimeter largestPart numberOfParts
  have h := p.perimeter_eq
  omega

/-- Distinct present part sizes divisible by `k`.  The finset is indexed from
zero, so `i.1 + 1` is the corresponding positive part size. -/
def Partition.oddStatistic {n : ℕ} (k : ℕ) (p : Partition n) : ℕ :=
  (Finset.univ.filter fun i : Fin (p.largest.1 + 1) ↦
    k ∣ i.1 + 1 ∧ 0 < (p.multiplicity i).1).card

/-- Distinct part sizes whose multiplicity is at least `k`. -/
def Partition.frequencyStatistic {n : ℕ} (k : ℕ) (p : Partition n) : ℕ :=
  (Finset.univ.filter fun i : Fin (p.largest.1 + 1) ↦
    k ≤ (p.multiplicity i).1).card

/-- Number of nonempty perimeter-`n` partitions having exactly `j` distinct
present part sizes divisible by `k`.  It is zero at `n = 0` because
`Partition 0` is empty. -/
def FO (j k n : ℕ) : ℕ :=
  (Finset.univ.filter fun p : Partition n ↦ p.oddStatistic k = j).card

/-- Number of nonempty perimeter-`n` partitions having exactly `j` distinct
part sizes of multiplicity at least `k`.  It is zero at `n = 0`. -/
def FD (j k n : ℕ) : ℕ :=
  (Finset.univ.filter fun p : Partition n ↦ p.frequencyStatistic k = j).card

@[simp] theorem FO_zero (j k : ℕ) : FO j k 0 = 0 := by
  simp only [FO, Finset.card_eq_zero, Finset.filter_eq_empty_iff]
  intro p
  exact p.largest.elim0

@[simp] theorem FD_zero (j k : ℕ) : FD j k 0 = 0 := by
  simp only [FD, Finset.card_eq_zero, Finset.filter_eq_empty_iff]
  intro p
  exact p.largest.elim0

/-- The perimeter equidistribution theorem at modulus two. -/
theorem fd_eq_fo_two (j n : ℕ) : FD j 2 n = FO j 2 n := by
  sorry

/-- For every fixed statistic value and every modulus at least three, the real
quotient of the two counting functions tends to zero. -/
theorem fo_div_fd_tendsto_zero (j k : ℕ) (hk : 3 ≤ k) :
    Tendsto (fun n : ℕ ↦ (FO j k n : ℝ) / (FD j k n : ℝ)) atTop (𝓝 0) := by
  sorry

/-- Eventual strict dominance, as a consequence of the preceding asymptotic. -/
theorem fo_lt_fd_eventually (j k : ℕ) (hk : 3 ≤ k) :
    ∃ N : ℕ, ∀ n ≥ N, FO j k n < FD j k n := by
  sorry

#print axioms fd_eq_fo_two
#print axioms fo_div_fd_tendsto_zero
#print axioms fo_lt_fd_eventually

end PerimeterPartitions
