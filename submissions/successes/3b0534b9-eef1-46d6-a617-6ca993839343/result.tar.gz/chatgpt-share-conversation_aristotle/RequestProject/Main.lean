import Mathlib

open Filter Finset
open scoped BigOperators Topology

set_option maxHeartbeats 8000000
set_option maxRecDepth 4000
set_option relaxedAutoImplicit false
set_option autoImplicit false

namespace FixedPerimeter

/-- A finite multiplicity profile for a partition of perimeter `n`: entry `i` is
its multiplicity of the part `i+1`.  The bounds are harmless, since a
perimeter-`n` partition has no part or multiplicity exceeding `n`. -/
abbrev Profile (n : ℕ) := Fin n → Fin (n + 1)

/-- Number of parts represented by a profile. -/
def partCount {n : ℕ} (p : Profile n) : ℕ := ∑ i, (p i : ℕ)

/-- Largest present part size (zero for the empty profile). -/
def largestPart {n : ℕ} (p : Profile n) : ℕ :=
  Finset.univ.sup fun i ↦ if (p i : ℕ) = 0 then 0 else i.1 + 1

/-- Perimeter = largest part + number of parts - 1. -/
def perimeter {n : ℕ} (p : Profile n) : ℕ := largestPart p + partCount p - 1

/-- Number of present part sizes divisible by `k`. -/
def divisibleSizeCount {n : ℕ} (k : ℕ) (p : Profile n) : ℕ :=
  (Finset.univ.filter fun i ↦ (p i : ℕ) ≠ 0 ∧ k ∣ i.1 + 1).card

/-- Number of part sizes occurring at least `k` times. -/
def frequentSizeCount {n : ℕ} (k : ℕ) (p : Profile n) : ℕ :=
  (Finset.univ.filter fun i ↦ k ≤ (p i : ℕ)).card

/-- `FO j k n` from the transcript. -/
def FO (j k n : ℕ) : ℕ :=
  (Finset.univ.filter fun p : Profile n ↦
    perimeter p = n ∧ divisibleSizeCount k p = j).card

/-- `FD j k n` from the transcript. -/
def FD (j k n : ℕ) : ℕ :=
  (Finset.univ.filter fun p : Profile n ↦
    perimeter p = n ∧ frequentSizeCount k p = j).card

/-- The strengthened intended claim for `k ≥ 3`. -/
def StrengthenedClaim : Prop :=
  ∀ j k : ℕ, 3 ≤ k →
    Tendsto (fun n : ℕ ↦ (FO j k n : ℝ) / (FD j k n : ℝ)) atTop (𝓝 0)

/-- The complete corrected claim in the transcript: exact equality for `k = 2`,
and asymptotic domination for every fixed `j` when `k ≥ 3`. -/
def IntendedClaim : Prop :=
  (∀ j n : ℕ, FO j 2 n = FD j 2 n) ∧ StrengthenedClaim

/-- The eventual strict inequality conjectured in the source follows from the
strengthened limit, once positivity of the denominator is known eventually. -/
theorem eventually_strict_of_ratio_tendsto_zero
    (a b : ℕ → ℕ)
    (hb : ∀ᶠ n in atTop, 0 < b n)
    (hlim : Tendsto (fun n ↦ (a n : ℝ) / (b n : ℝ)) atTop (𝓝 0)) :
    ∀ᶠ n in atTop, a n < b n := by
  have h1 : ∀ᶠ n in atTop, (a n : ℝ) / (b n : ℝ) < 1 := by
    exact hlim.eventually (gt_mem_nhds zero_lt_one)
  filter_upwards [hb, h1] with n hb hn
  rw [div_lt_one (Nat.cast_pos.mpr hb)] at hn
  exact Nat.cast_lt.mp hn

/-- Abstract, fully explicit form of the corrected dominant-pole endgame.  It
records the complete asymptotic information needed after partial fractions:
the denominator sequence has a positive exponential lower bound, while the
numerator sequence has a polynomial-times-exponential upper bound with a
strictly smaller base. -/
theorem ratio_tendsto_zero_of_exponential_separation
    (a b : ℕ → ℕ) (C c α β : ℝ) (d : ℕ)
    (hC : 0 ≤ C) (hc : 0 < c) (hα : 0 ≤ α) (hβα : α < β)
    (ha : ∀ᶠ n in atTop, (a n : ℝ) ≤ C * (n : ℝ) ^ d * α ^ n)
    (hb : ∀ᶠ n in atTop, c * β ^ n ≤ (b n : ℝ)) :
    Tendsto (fun n ↦ (a n : ℝ) / (b n : ℝ)) atTop (𝓝 0) := by
  -- Since α < β and α ≥ 0, we have β > 0
  have hβpos : 0 < β := by linarith
  -- α/β < 1 since α < β and β > 0
  have hαβ_lt_1 : α / β < 1 := by rwa [div_lt_one hβpos]
  have hαβ_nn : 0 ≤ α / β := div_nonneg hα (le_of_lt hβpos)
  -- The key limit: n^d * (α/β)^n → 0
  have key : Tendsto (fun n : ℕ => (n : ℝ) ^ d * (α / β) ^ n) atTop (𝓝 0) := by
    have hlt : ‖α / β‖ < 1 := by
      rw [Real.norm_eq_abs, abs_of_nonneg hαβ_nn]
      exact hαβ_lt_1
    -- Use summability to get the limit
    exact (summable_pow_mul_geometric_of_norm_lt_one d hlt).tendsto_atTop_zero
  -- Multiply key by C/c to get the bound
  have key' : Tendsto (fun n : ℕ => (C / c) * (n : ℝ) ^ d * (α / β) ^ n) atTop (𝓝 0) := by
    have := key.const_mul (C / c)
    simp only [mul_zero] at this
    convert this using 1
    funext n
    ring
  -- Now use squeeze theorem: 0 ≤ a n / b n ≤ bound → 0
  apply squeeze_zero_norm' _ key'
  -- Get the eventual conditions from ha and hb
  rw [eventually_atTop] at ha hb ⊢
  obtain ⟨Na, ha⟩ := ha
  obtain ⟨Nb, hb⟩ := hb
  use max Na Nb
  intro n hn
  have hnNa : n ≥ Na := le_trans (le_max_left _ _) hn
  have hnNb : n ≥ Nb := le_trans (le_max_right _ _) hn
  have ha_n := ha n hnNa
  have hb_n := hb n hnNb
  -- The norm of a non-negative real is itself
  rw [Real.norm_eq_abs, abs_of_nonneg (by positivity : (0 : ℝ) ≤ (a n : ℝ) / (b n : ℝ))]
  -- Handle the case when b n = 0
  by_cases hbn : (b n : ℝ) = 0
  · simp [hbn]
    positivity
  · calc (a n : ℝ) / (b n : ℝ)
        ≤ (C * (n : ℝ) ^ d * α ^ n) / (b n : ℝ) := by gcongr
          _ ≤ (C * (n : ℝ) ^ d * α ^ n) / (c * β ^ n) := by gcongr
          _ = C / c * (n : ℝ) ^ d * (α / β) ^ n := by
              rw [div_pow]; field_simp

/-- Concrete application of the corrected dominant-pole endgame to the two
fixed-perimeter counting functions.  This isolates exactly the asymptotic
bounds that the generating-function and partial-fraction portion must supply. -/
theorem FO_div_FD_tendsto_zero_of_exponential_bounds
    (j k : ℕ) (C c α β : ℝ) (d : ℕ)
    (hC : 0 ≤ C) (hc : 0 < c) (hα : 0 ≤ α) (hβα : α < β)
    (hFO : ∀ᶠ n in atTop,
      (FO j k n : ℝ) ≤ C * (n : ℝ) ^ d * α ^ n)
    (hFD : ∀ᶠ n in atTop,
      c * β ^ n ≤ (FD j k n : ℝ)) :
    Tendsto (fun n : ℕ ↦ (FO j k n : ℝ) / (FD j k n : ℝ)) atTop (𝓝 0) := by
  exact ratio_tendsto_zero_of_exponential_separation
    (FO j k) (FD j k) C c α β d hC hc hα hβα hFO hFD

end FixedPerimeter
